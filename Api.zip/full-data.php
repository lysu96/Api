<?php
require_once 'model/function-api.php';
$api = new Api();
$api->fullData();

// require_once 'model/Rest.php';
// $api = new Rest();
// $api->fullData();

?>